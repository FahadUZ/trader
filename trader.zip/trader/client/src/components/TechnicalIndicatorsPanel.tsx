import { TechnicalIndicator } from "./TechnicalIndicator";

interface Indicator {
  name: string;
  value: string;
  signal: "Bullish" | "Bearish" | "Neutral" | "Oversold" | "Overbought" | "Bullish Cross" | "Bearish Cross" |
          "Strong Uptrend" | "Strong Downtrend" | "Weak/No Trend" | 
          "Above VWAP (Bullish)" | "Below VWAP (Bearish)" | 
          "Above Cloud (Bullish)" | "Below Cloud (Bearish)" | 
          "Above Fib 0.618" | "Below Fib 0.618";
  change?: number;
}

interface TechnicalIndicatorsPanelProps {
  indicators: Indicator[];
}

export function TechnicalIndicatorsPanel({ indicators }: TechnicalIndicatorsPanelProps) {
  const categorizeIndicators = () => {
    const momentum = indicators.filter(i => 
      ['RSI', 'Stochastic', 'MACD'].some(name => i.name.includes(name))
    );
    
    const trend = indicators.filter(i => 
      ['EMA', 'ADX', 'Ichimoku', 'Parabolic SAR'].some(name => i.name.includes(name))
    );
    
    const volatilityVolume = indicators.filter(i => 
      ['Bollinger', 'VWAP'].some(name => i.name.includes(name))
    );
    
    const keyLevels = indicators.filter(i => 
      ['Fibonacci'].some(name => i.name.includes(name))
    );

    return { momentum, trend, volatilityVolume, keyLevels };
  };

  const { momentum, trend, volatilityVolume, keyLevels } = categorizeIndicators();

  const IndicatorSection = ({ title, items }: { title: string; items: Indicator[] }) => (
    items.length > 0 ? (
      <div className="mb-6">
        <h4 className="text-sm font-semibold text-muted-foreground mb-3 uppercase tracking-wide">{title}</h4>
        <div className="grid grid-cols-1 gap-3">
          {items.map((indicator) => (
            <TechnicalIndicator key={indicator.name} {...indicator} />
          ))}
        </div>
      </div>
    ) : null
  );

  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">Technical Analysis</h3>
      <div className="space-y-1">
        <IndicatorSection title="Momentum Indicators" items={momentum} />
        <IndicatorSection title="Trend Indicators" items={trend} />
        <IndicatorSection title="Volatility & Volume" items={volatilityVolume} />
        <IndicatorSection title="Key Levels" items={keyLevels} />
      </div>
    </div>
  );
}
