import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Zap, TrendingUp } from "lucide-react";
import type { TradingMode } from "@shared/schema";

interface TradingModeSelectorProps {
  value: TradingMode;
  onChange: (value: TradingMode) => void;
}

export function TradingModeSelector({ value, onChange }: TradingModeSelectorProps) {
  return (
    <ToggleGroup
      type="single"
      value={value}
      onValueChange={(newValue) => {
        if (newValue) onChange(newValue as TradingMode);
      }}
      className="border rounded-lg p-1"
    >
      <ToggleGroupItem 
        value="scalping" 
        aria-label="Scalping Mode"
        className="data-[state=on]:bg-trading-buy data-[state=on]:text-white gap-2"
      >
        <Zap className="h-4 w-4" />
        <span className="hidden sm:inline">Scalping</span>
      </ToggleGroupItem>
      <ToggleGroupItem 
        value="swing" 
        aria-label="Swing Mode"
        className="data-[state=on]:bg-primary data-[state=on]:text-white gap-2"
      >
        <TrendingUp className="h-4 w-4" />
        <span className="hidden sm:inline">Swing</span>
      </ToggleGroupItem>
    </ToggleGroup>
  );
}
