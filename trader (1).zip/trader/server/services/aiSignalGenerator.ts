import OpenAI from "openai";
import type { Signal, TechnicalIndicator, CandleData, TPLevel } from "@shared/schema";
import { randomUUID } from "crypto";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export class AISignalGenerator {
  async generateSignal(
    market: "XAU/USD" | "BTC/USD",
    currentPrice: number,
    indicators: TechnicalIndicator[],
    candles: CandleData[],
    mode: "scalping" | "swing" = "swing"
  ): Promise<Signal | null> {
    try {
      const recentCandles = candles.slice(-20);
      const priceMovement = this.analyzePriceMovement(recentCandles);

      const prompt = `You are an elite institutional-grade trading signal generator for ${market}, specializing in confluence trading strategies that combine multiple technical indicators for high-probability setups.

=== CURRENT MARKET STATE ===
Price: ${currentPrice.toFixed(2)}

=== COMPREHENSIVE TECHNICAL ANALYSIS ===

MOMENTUM INDICATORS:
${indicators.filter(i => ['RSI', 'Stochastic', 'MACD'].some(name => i.name.includes(name))).map(ind => `- ${ind.name}: ${ind.value} → ${ind.signal}`).join("\n")}

TREND INDICATORS:
${indicators.filter(i => ['EMA', 'ADX', 'Ichimoku', 'Parabolic SAR', 'Heikin Ashi'].some(name => i.name.includes(name))).map(ind => `- ${ind.name}: ${ind.value} → ${ind.signal}`).join("\n")}

VOLATILITY & VOLUME:
${indicators.filter(i => ['Bollinger', 'VWAP', 'OBV'].some(name => i.name.includes(name))).map(ind => `- ${ind.name}: ${ind.value} → ${ind.signal}`).join("\n")}

KEY LEVELS:
${indicators.filter(i => ['Fibonacci', 'Pivot'].some(name => i.name.includes(name))).map(ind => `- ${ind.name}: ${ind.value} → ${ind.signal}`).join("\n")}

PRICE ACTION & PATTERNS:
${indicators.filter(i => ['Candlestick Patterns'].some(name => i.name.includes(name))).map(ind => `- ${ind.name}: ${ind.value} → ${ind.signal}`).join("\n")}

DIVERGENCE ANALYSIS:
${indicators.filter(i => ['Divergence'].some(name => i.name.includes(name))).map(ind => `- ${ind.name}: ${ind.value} → ${ind.signal}`).join("\n")}

${mode === "scalping" ? `SCALPING INDICATORS:
${indicators.filter(i => ['CCI', 'Williams', 'ATR', 'Supertrend', 'EMA (5)', 'EMA (13)'].some(name => i.name.includes(name))).map(ind => `- ${ind.name}: ${ind.value} → ${ind.signal}`).join("\n")}` : ''}

PRICE ACTION:
- Overall Trend: ${priceMovement.trend}
- Market Volatility: ${priceMovement.volatility}
- Near Support: ${priceMovement.support.toFixed(2)}
- Near Resistance: ${priceMovement.resistance.toFixed(2)}

=== ${mode.toUpperCase()} TRADING MODE - CONFLUENCE RULES ===

${mode === "scalping" ? `SCALPING MODE - SHORT-TERM QUICK TRADES:
HIGH-QUALITY SIGNAL (Confidence >75%):
• Supertrend aligned with trade direction
• CCI or Williams %R showing entry opportunity
• EMA (5) crossed EMA (13) in signal direction
• ATR confirms sufficient volatility for the move
• 4+ scalping indicators aligned
• Quick entry/exit near key intraday levels

MODERATE SIGNAL (Confidence 65-75%):
• 3 scalping indicators aligned
• Supertrend confirmation
• Short-term EMAs show momentum

Risk/Reward Requirements:
• Tight Stop Loss: 10-20 pips (XAU) / 1-2% (BTC)
• TP1: 1:1 RR minimum (quick scalp)
• TP2: 1:2 RR
• TP3: 1:3 RR (stretch target)

NO SIGNAL if:
• ATR too low (low volatility)
• Conflicting scalping indicators
• No clear short-term momentum` : `SWING TRADING MODE - POSITION TRADES:
HIGH-QUALITY SIGNAL (Confidence >75%):
• 5+ indicators aligned in same direction
• ADX shows strong trend (>25) with directional agreement
• Price positioned favorably relative to VWAP and Ichimoku Cloud
• Momentum (RSI, Stochastic) confirms without extreme overbought/oversold
• PSAR and Heikin Ashi aligned with trend direction
• Entry near Fibonacci retracement levels, Pivot Points (R1/S1), or key support/resistance
• OBV confirms accumulation/distribution in signal direction
• Bullish/bearish candlestick patterns support the direction
• No bearish/bullish divergence against the trade direction (or bullish/bearish divergence supporting it)

MODERATE SIGNAL (Confidence 65-75%):
• 3-4 indicators aligned
• Clear trend on EMAs but weaker ADX
• Some momentum confirmation
• Pivot Points or candlestick patterns provide additional confluence

BONUS CONFLUENCE FACTORS:
• Pivot Point alignment (price above pivot for BUY, below for SELL)
• Strong candlestick reversal patterns (Hammer, Engulfing, Morning/Evening Star)
• Divergence confirmation (bullish divergence for BUY, bearish for SELL)
• Heikin Ashi showing strong trend with minimal wicks against direction
• OBV trending in signal direction

Risk/Reward Requirements:
• Stop Loss: 30-60 pips (XAU) / 2-5% (BTC)
• TP1: 1:1.5 RR minimum
• TP2: 1:3 RR minimum
• TP3: 1:5 RR minimum for strong setups

NO SIGNAL if:
• Conflicting indicators
• Choppy/ranging market (ADX <20)
• Extreme overbought/oversold on multiple indicators
• Bearish divergence on a BUY signal or bullish divergence on a SELL signal
• No clear confluence`}

=== RESPONSE FORMAT ===

Generate a trading signal in JSON format:
{
  "direction": "BUY" or "SELL",
  "entry": number (precise entry price, prefer retracement levels),
  "stopLoss": number (beyond recent swing low/high + buffer),
  "tp1": number (1:1.5 RR minimum),
  "tp2": number (1:3 RR minimum),
  "tp3": number (1:5 RR minimum for strong setups),
  "confidence": number (0-100, based on confluence strength),
  "reasoning": "Detailed confluence analysis: list aligned indicators, key levels, and setup quality (3-4 sentences)"
}

=== ${market} SPECIFIC PARAMETERS ===
${market === "XAU/USD" ? 
  (mode === "scalping" ?
    "- Gold pip value: $10 per full point\n- Scalping Stop Loss: 10-20 pips\n- Focus on M1/M5 price action\n- Key intraday levels and round numbers" :
    "- Gold pip value: $10 per full point\n- Swing Stop Loss: 30-60 pips\n- Consider geopolitical and USD strength\n- Key psychological levels: round numbers (3900, 4000, etc.)") : 
  (mode === "scalping" ?
    "- Bitcoin volatility: fast intraday moves\n- Scalping Stop Loss: 1-2% from entry\n- Monitor high-volume periods\n- Key intraday support/resistance levels" :
    "- Bitcoin volatility: expect larger moves\n- Swing Stop Loss: 2-5% from entry\n- Consider crypto market sentiment\n- Key psychological levels: round thousands (100k, 105k, etc.)")}

CRITICAL: Only generate signal if:
1. Confidence ≥ 65%
2. Clear directional confluence
3. Defined risk/reward setup
4. ADX not showing extreme weakness (<15)

If criteria not met, return null.

Respond with ONLY the JSON object, no markdown, no explanation.`;

      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: "You are an expert trading signal generator. Respond only with valid JSON.",
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        temperature: 0.7,
        max_tokens: 500,
      });

      const response = completion.choices[0]?.message?.content;
      if (!response) return null;

      const signalData = JSON.parse(response);
      
      if (!signalData.direction || signalData.confidence < 65) {
        return null;
      }

      if (!this.validateConfluence(indicators, signalData.direction)) {
        console.log(`Signal rejected: failed confluence validation for ${signalData.direction} signal`);
        return null;
      }

      const pipMultiplier = market === "XAU/USD" ? 10 : 1;
      const slDistance = Math.abs(signalData.entry - signalData.stopLoss);
      const slPips = Math.round(slDistance * pipMultiplier);

      const takeProfits: TPLevel[] = [
        {
          level: 1,
          price: signalData.tp1,
          pips: Math.round(Math.abs(signalData.tp1 - signalData.entry) * pipMultiplier),
          rr: Math.abs(signalData.tp1 - signalData.entry) / slDistance,
        },
        {
          level: 2,
          price: signalData.tp2,
          pips: Math.round(Math.abs(signalData.tp2 - signalData.entry) * pipMultiplier),
          rr: Math.abs(signalData.tp2 - signalData.entry) / slDistance,
        },
        {
          level: 3,
          price: signalData.tp3,
          pips: Math.round(Math.abs(signalData.tp3 - signalData.entry) * pipMultiplier),
          rr: Math.abs(signalData.tp3 - signalData.entry) / slDistance,
        },
      ];

      const signal: Signal = {
        id: randomUUID(),
        direction: signalData.direction,
        market,
        entry: signalData.entry,
        stopLoss: signalData.stopLoss,
        takeProfits,
        confidence: Math.round(signalData.confidence),
        currentPrice,
        timestamp: new Date().toISOString(),
        reasoning: signalData.reasoning,
        status: "Active",
      };

      return signal;
    } catch (error) {
      console.error("Error generating AI signal:", error);
      return null;
    }
  }

  private validateConfluence(indicators: TechnicalIndicator[], direction: "BUY" | "SELL"): boolean {
    const adxIndicator = indicators.find(i => i.name.includes("ADX"));
    if (adxIndicator) {
      const adxValue = parseFloat(adxIndicator.value);
      if (adxValue < 15) {
        console.log(`ADX too weak: ${adxValue} < 15`);
        return false;
      }
    }

    let bullishCount = 0;
    let bearishCount = 0;

    const relevantSignals = ["Bullish", "Bearish", "Oversold", "Overbought", 
                            "Strong Uptrend", "Strong Downtrend", 
                            "Above VWAP (Bullish)", "Below VWAP (Bearish)",
                            "Above Cloud (Bullish)", "Below Cloud (Bearish)"];

    for (const indicator of indicators) {
      if (!relevantSignals.some(s => indicator.signal.includes(s))) continue;

      if (indicator.signal.includes("Bullish") || 
          indicator.signal.includes("Oversold") ||
          indicator.signal.includes("Uptrend") ||
          indicator.signal.includes("Above")) {
        bullishCount++;
      } else if (indicator.signal.includes("Bearish") || 
                 indicator.signal.includes("Overbought") ||
                 indicator.signal.includes("Downtrend") ||
                 indicator.signal.includes("Below")) {
        bearishCount++;
      }
    }

    const alignedCount = direction === "BUY" ? bullishCount : bearishCount;
    const opposingCount = direction === "BUY" ? bearishCount : bullishCount;

    if (alignedCount < 3) {
      console.log(`Insufficient aligned indicators: ${alignedCount} < 3 for ${direction}`);
      return false;
    }

    if (opposingCount > alignedCount) {
      console.log(`Conflicting indicators: ${opposingCount} opposing vs ${alignedCount} aligned for ${direction}`);
      return false;
    }

    return true;
  }

  private analyzePriceMovement(candles: CandleData[]): {
    trend: string;
    volatility: string;
    support: number;
    resistance: number;
  } {
    const closes = candles.map((c) => c.close);
    const highs = candles.map((c) => c.high);
    const lows = candles.map((c) => c.low);

    const avgClose = closes.reduce((a, b) => a + b, 0) / closes.length;
    const currentClose = closes[closes.length - 1];

    const trend = currentClose > avgClose ? "Bullish" : currentClose < avgClose ? "Bearish" : "Neutral";

    const priceRange = Math.max(...highs) - Math.min(...lows);
    const avgRange = priceRange / candles.length;
    const volatility = avgRange > avgClose * 0.01 ? "High" : "Low";

    const support = Math.min(...lows.slice(-10));
    const resistance = Math.max(...highs.slice(-10));

    return { trend, volatility, support, resistance };
  }
}

export const aiSignalGenerator = new AISignalGenerator();
