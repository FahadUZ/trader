import { RSI, MACD, EMA, BollingerBands, Stochastic, ADX, PSAR, CCI, WilliamsR, ATR, OBV, HeikinAshi } from "technicalindicators";
import type { CandleData, TechnicalIndicator, TimeframeAnalysis } from "@shared/schema";

export class TechnicalIndicatorsService {
  calculateRSI(candles: CandleData[], period: number = 14): number {
    const closes = candles.map((c) => c.close);
    const rsiValues = RSI.calculate({ values: closes, period });
    return rsiValues[rsiValues.length - 1] || 50;
  }

  calculateMACD(candles: CandleData[]): {
    value: number;
    signal: number;
    histogram: number;
  } {
    const closes = candles.map((c) => c.close);
    const macdValues = MACD.calculate({
      values: closes,
      fastPeriod: 12,
      slowPeriod: 26,
      signalPeriod: 9,
      SimpleMAOscillator: false,
      SimpleMASignal: false,
    });

    const latest = macdValues[macdValues.length - 1];
    if (!latest) {
      return { value: 0, signal: 0, histogram: 0 };
    }

    return {
      value: latest.MACD || 0,
      signal: latest.signal || 0,
      histogram: latest.histogram || 0,
    };
  }

  calculateEMA(candles: CandleData[], period: number): number {
    const closes = candles.map((c) => c.close);
    const emaValues = EMA.calculate({ values: closes, period });
    return emaValues[emaValues.length - 1] || closes[closes.length - 1];
  }

  calculateBollingerBands(candles: CandleData[], period: number = 20): {
    upper: number;
    middle: number;
    lower: number;
  } {
    const closes = candles.map((c) => c.close);
    const bbValues = BollingerBands.calculate({
      values: closes,
      period,
      stdDev: 2,
    });

    const latest = bbValues[bbValues.length - 1];
    if (!latest) {
      const lastClose = closes[closes.length - 1];
      return { upper: lastClose, middle: lastClose, lower: lastClose };
    }

    return {
      upper: latest.upper,
      middle: latest.middle,
      lower: latest.lower,
    };
  }

  calculateStochastic(candles: CandleData[]): { k: number; d: number } {
    const highs = candles.map((c) => c.high);
    const lows = candles.map((c) => c.low);
    const closes = candles.map((c) => c.close);

    const stochValues = Stochastic.calculate({
      high: highs,
      low: lows,
      close: closes,
      period: 14,
      signalPeriod: 3,
    });

    const latest = stochValues[stochValues.length - 1];
    if (!latest) {
      return { k: 50, d: 50 };
    }

    return { k: latest.k, d: latest.d };
  }

  calculateADX(candles: CandleData[], period: number = 14): { adx: number; pdi: number; mdi: number } {
    const highs = candles.map((c) => c.high);
    const lows = candles.map((c) => c.low);
    const closes = candles.map((c) => c.close);

    const adxValues = ADX.calculate({
      high: highs,
      low: lows,
      close: closes,
      period,
    });

    const latest = adxValues[adxValues.length - 1];
    if (!latest) {
      return { adx: 0, pdi: 0, mdi: 0 };
    }

    return { 
      adx: latest.adx || 0, 
      pdi: latest.pdi || 0, 
      mdi: latest.mdi || 0 
    };
  }

  calculatePSAR(candles: CandleData[]): number {
    const highs = candles.map((c) => c.high);
    const lows = candles.map((c) => c.low);

    const psarValues = PSAR.calculate({
      high: highs,
      low: lows,
      step: 0.02,
      max: 0.2,
    });

    return psarValues[psarValues.length - 1] || candles[candles.length - 1].close;
  }

  calculateVWAP(candles: CandleData[]): number {
    let cumulativePriceVolume = 0;
    let cumulativeVolume = 0;

    for (const candle of candles) {
      const typicalPrice = (candle.high + candle.low + candle.close) / 3;
      const volume = candle.volume || 1;
      cumulativePriceVolume += typicalPrice * volume;
      cumulativeVolume += volume;
    }

    return cumulativeVolume > 0 ? cumulativePriceVolume / cumulativeVolume : candles[candles.length - 1].close;
  }

  calculateIchimoku(candles: CandleData[]): {
    tenkanSen: number;
    kijunSen: number;
    senkouSpanA: number;
    senkouSpanB: number;
    chikouSpan: number;
    cloudSignal: "Bullish" | "Bearish" | "Neutral";
  } {
    if (candles.length < 52) {
      const lastClose = candles[candles.length - 1]?.close || 0;
      return {
        tenkanSen: lastClose,
        kijunSen: lastClose,
        senkouSpanA: lastClose,
        senkouSpanB: lastClose,
        chikouSpan: lastClose,
        cloudSignal: "Neutral",
      };
    }

    const getHighLow = (data: CandleData[], period: number, offset: number = 0) => {
      const endIdx = data.length - offset;
      const startIdx = Math.max(0, endIdx - period);
      const slice = data.slice(startIdx, endIdx);
      if (slice.length === 0) return 0;
      const high = Math.max(...slice.map((c) => c.high));
      const low = Math.min(...slice.map((c) => c.low));
      return (high + low) / 2;
    };

    const tenkanSen = getHighLow(candles, 9, 0);
    const kijunSen = getHighLow(candles, 26, 0);
    const senkouSpanA = (tenkanSen + kijunSen) / 2;
    const senkouSpanB = getHighLow(candles, 52, 0);
    
    const chikouIdx = Math.max(0, candles.length - 26);
    const chikouSpan = candles[chikouIdx]?.close || candles[candles.length - 1].close;

    const currentPrice = candles[candles.length - 1].close;
    const cloudTop = Math.max(senkouSpanA, senkouSpanB);
    const cloudBottom = Math.min(senkouSpanA, senkouSpanB);

    let cloudSignal: "Bullish" | "Bearish" | "Neutral" = "Neutral";
    if (currentPrice > cloudTop && senkouSpanA > senkouSpanB) {
      cloudSignal = "Bullish";
    } else if (currentPrice < cloudBottom && senkouSpanA < senkouSpanB) {
      cloudSignal = "Bearish";
    }

    return {
      tenkanSen,
      kijunSen,
      senkouSpanA,
      senkouSpanB,
      chikouSpan,
      cloudSignal,
    };
  }

  calculateCCI(candles: CandleData[], period: number = 20): number {
    const highs = candles.map((c) => c.high);
    const lows = candles.map((c) => c.low);
    const closes = candles.map((c) => c.close);

    const cciValues = CCI.calculate({
      high: highs,
      low: lows,
      close: closes,
      period,
    });

    return cciValues[cciValues.length - 1] || 0;
  }

  calculateWilliamsR(candles: CandleData[], period: number = 14): number {
    const highs = candles.map((c) => c.high);
    const lows = candles.map((c) => c.low);
    const closes = candles.map((c) => c.close);

    const wrValues = WilliamsR.calculate({
      high: highs,
      low: lows,
      close: closes,
      period,
    });

    return wrValues[wrValues.length - 1] || -50;
  }

  calculateATR(candles: CandleData[], period: number = 14): number {
    const highs = candles.map((c) => c.high);
    const lows = candles.map((c) => c.low);
    const closes = candles.map((c) => c.close);

    const atrValues = ATR.calculate({
      high: highs,
      low: lows,
      close: closes,
      period,
    });

    return atrValues[atrValues.length - 1] || 0;
  }

  calculateSupertrend(candles: CandleData[], period: number = 10, multiplier: number = 3): {
    supertrend: number;
    direction: "Bullish" | "Bearish";
  } {
    if (candles.length < period) {
      const lastClose = candles[candles.length - 1]?.close || 0;
      return { supertrend: lastClose, direction: "Neutral" as any };
    }

    const atr = this.calculateATR(candles, period);
    const hl2 = candles.map(c => (c.high + c.low) / 2);
    
    const basicUpperBand = hl2.map((value, i) => {
      const candleATR = this.calculateATR(candles.slice(0, i + 1), Math.min(period, i + 1));
      return value + multiplier * candleATR;
    });
    
    const basicLowerBand = hl2.map((value, i) => {
      const candleATR = this.calculateATR(candles.slice(0, i + 1), Math.min(period, i + 1));
      return value - multiplier * candleATR;
    });

    let finalUpperBand = basicUpperBand[basicUpperBand.length - 1];
    let finalLowerBand = basicLowerBand[basicLowerBand.length - 1];
    
    const currentClose = candles[candles.length - 1].close;
    const previousClose = candles[candles.length - 2]?.close || currentClose;

    let supertrend: number;
    let direction: "Bullish" | "Bearish";

    if (currentClose <= finalLowerBand) {
      supertrend = finalLowerBand;
      direction = "Bearish";
    } else if (currentClose >= finalUpperBand) {
      supertrend = finalUpperBand;
      direction = "Bullish";
    } else {
      supertrend = previousClose <= finalLowerBand ? finalLowerBand : finalUpperBand;
      direction = previousClose <= finalLowerBand ? "Bearish" : "Bullish";
    }

    return { supertrend, direction };
  }

  calculateFibonacci(candles: CandleData[]): {
    high: number;
    low: number;
    swingHigh: number;
    swingLow: number;
    levels: { level: number; price: number; label: string }[];
    trend: "Uptrend" | "Downtrend";
  } {
    if (candles.length < 20) {
      const lastClose = candles[candles.length - 1]?.close || 0;
      return {
        high: lastClose,
        low: lastClose,
        swingHigh: lastClose,
        swingLow: lastClose,
        levels: [],
        trend: "Uptrend",
      };
    }

    const findSwingHigh = (data: CandleData[], lookback: number = 20): number => {
      const recentCandles = data.slice(-lookback);
      const highs = recentCandles.map(c => c.high);
      let maxHigh = -Infinity;
      let maxIdx = -1;
      
      for (let i = 2; i < highs.length - 2; i++) {
        if (highs[i] > highs[i-1] && highs[i] > highs[i-2] &&
            highs[i] > highs[i+1] && highs[i] > highs[i+2] &&
            highs[i] > maxHigh) {
          maxHigh = highs[i];
          maxIdx = i;
        }
      }
      
      return maxIdx >= 0 ? maxHigh : Math.max(...highs);
    };

    const findSwingLow = (data: CandleData[], lookback: number = 20): number => {
      const recentCandles = data.slice(-lookback);
      const lows = recentCandles.map(c => c.low);
      let minLow = Infinity;
      let minIdx = -1;
      
      for (let i = 2; i < lows.length - 2; i++) {
        if (lows[i] < lows[i-1] && lows[i] < lows[i-2] &&
            lows[i] < lows[i+1] && lows[i] < lows[i+2] &&
            lows[i] < minLow) {
          minLow = lows[i];
          minIdx = i;
        }
      }
      
      return minIdx >= 0 ? minLow : Math.min(...lows);
    };

    const swingHigh = findSwingHigh(candles, 30);
    const swingLow = findSwingLow(candles, 30);
    const diff = swingHigh - swingLow;
    const currentPrice = candles[candles.length - 1].close;
    
    const trend: "Uptrend" | "Downtrend" = currentPrice > (swingHigh + swingLow) / 2 ? "Uptrend" : "Downtrend";

    const fibLevels = [
      { level: 0, label: "0%" },
      { level: 0.236, label: "23.6%" },
      { level: 0.382, label: "38.2%" },
      { level: 0.5, label: "50%" },
      { level: 0.618, label: "61.8%" },
      { level: 0.786, label: "78.6%" },
      { level: 1, label: "100%" }
    ];

    const levels = fibLevels.map((fib) => ({
      level: fib.level,
      price: swingHigh - diff * fib.level,
      label: fib.label,
    }));

    return {
      high: swingHigh,
      low: swingLow,
      swingHigh,
      swingLow,
      levels,
      trend,
    };
  }

  calculateOBV(candles: CandleData[]): number {
    const closes = candles.map((c) => c.close);
    const volumes = candles.map((c) => c.volume);
    
    const obvValues = OBV.calculate({ close: closes, volume: volumes });
    return obvValues[obvValues.length - 1] || 0;
  }

  calculatePivotPoints(candles: CandleData[]): {
    pivot: number;
    r1: number;
    r2: number;
    r3: number;
    s1: number;
    s2: number;
    s3: number;
    type: "Standard";
  } {
    const lastCandle = candles[candles.length - 1];
    const high = lastCandle.high;
    const low = lastCandle.low;
    const close = lastCandle.close;
    
    const pivot = (high + low + close) / 3;
    const r1 = 2 * pivot - low;
    const s1 = 2 * pivot - high;
    const r2 = pivot + (high - low);
    const s2 = pivot - (high - low);
    const r3 = high + 2 * (pivot - low);
    const s3 = low - 2 * (high - pivot);
    
    return {
      pivot,
      r1,
      r2,
      r3,
      s1,
      s2,
      s3,
      type: "Standard",
    };
  }

  calculateHeikinAshi(candles: CandleData[]): {
    open: number;
    close: number;
    high: number;
    low: number;
    trend: "Bullish" | "Bearish" | "Neutral";
  } {
    const opens = candles.map((c) => c.open);
    const closes = candles.map((c) => c.close);
    const highs = candles.map((c) => c.high);
    const lows = candles.map((c) => c.low);
    
    const haValues = HeikinAshi.calculate({
      open: opens,
      close: closes,
      high: highs,
      low: lows,
    }) as any[];
    
    const latest = haValues[haValues.length - 1];
    if (!latest) {
      return { 
        open: opens[opens.length - 1], 
        close: closes[closes.length - 1],
        high: highs[highs.length - 1],
        low: lows[lows.length - 1],
        trend: "Neutral" 
      };
    }
    
    const trend = latest.close > latest.open ? "Bullish" : 
                  latest.close < latest.open ? "Bearish" : "Neutral";
    
    return {
      open: latest.open,
      close: latest.close,
      high: latest.high,
      low: latest.low,
      trend,
    };
  }

  detectCandlestickPatterns(candles: CandleData[]): {
    patterns: string[];
    signal: "Bullish" | "Bearish" | "Neutral";
  } {
    const patterns: string[] = [];
    
    if (candles.length < 3) {
      return { patterns: [], signal: "Neutral" };
    }
    
    const current = candles[candles.length - 1];
    const previous = candles[candles.length - 2];
    const twoPrevious = candles[candles.length - 3];
    
    const currentBody = Math.abs(current.close - current.open);
    const currentRange = current.high - current.low;
    const previousBody = Math.abs(previous.close - previous.open);
    
    const isBullish = (c: CandleData) => c.close > c.open;
    const isBearish = (c: CandleData) => c.close < c.open;
    
    if (currentBody < currentRange * 0.1) {
      patterns.push("Doji");
    }
    
    if (isBullish(current) && currentBody > previousBody * 1.2 &&
        current.close > previous.high && current.open < previous.low) {
      patterns.push("Bullish Engulfing");
    }
    
    if (isBearish(current) && currentBody > previousBody * 1.2 &&
        current.close < previous.low && current.open > previous.high) {
      patterns.push("Bearish Engulfing");
    }
    
    const upperShadow = current.high - Math.max(current.open, current.close);
    const lowerShadow = Math.min(current.open, current.close) - current.low;
    
    if (lowerShadow > currentBody * 2 && upperShadow < currentBody * 0.3 && isBullish(current)) {
      patterns.push("Hammer (Bullish)");
    }
    
    if (upperShadow > currentBody * 2 && lowerShadow < currentBody * 0.3 && isBearish(current)) {
      patterns.push("Shooting Star (Bearish)");
    }
    
    if (isBearish(twoPrevious) && currentBody < previousBody * 0.5 && 
        isBullish(current) && current.close > twoPrevious.high) {
      patterns.push("Morning Star (Bullish)");
    }
    
    if (isBullish(twoPrevious) && currentBody < previousBody * 0.5 && 
        isBearish(current) && current.close < twoPrevious.low) {
      patterns.push("Evening Star (Bearish)");
    }
    
    const bullishPatterns = patterns.filter(p => p.includes("Bullish") || p.includes("Hammer") || p.includes("Morning"));
    const bearishPatterns = patterns.filter(p => p.includes("Bearish") || p.includes("Shooting") || p.includes("Evening"));
    
    const signal = bullishPatterns.length > bearishPatterns.length ? "Bullish" :
                   bearishPatterns.length > bullishPatterns.length ? "Bearish" : "Neutral";
    
    return { patterns, signal };
  }

  detectDivergences(candles: CandleData[]): {
    rsiDivergence: "Bullish" | "Bearish" | "None";
    macdDivergence: "Bullish" | "Bearish" | "None";
    stochDivergence: "Bullish" | "Bearish" | "None";
    overallSignal: "Bullish Divergence" | "Bearish Divergence" | "No Divergence";
  } {
    if (candles.length < 20) {
      return {
        rsiDivergence: "None",
        macdDivergence: "None",
        stochDivergence: "None",
        overallSignal: "No Divergence",
      };
    }
    
    const closes = candles.map((c) => c.close);
    const rsiValues = RSI.calculate({ values: closes, period: 14 });
    const macdValues = MACD.calculate({
      values: closes,
      fastPeriod: 12,
      slowPeriod: 26,
      signalPeriod: 9,
      SimpleMAOscillator: false,
      SimpleMASignal: false,
    });
    const stochValues = Stochastic.calculate({
      high: candles.map((c) => c.high),
      low: candles.map((c) => c.low),
      close: closes,
      period: 14,
      signalPeriod: 3,
    });
    
    const recentCandles = 10;
    const recentPrices = closes.slice(-recentCandles);
    const recentRSI = rsiValues.slice(-recentCandles);
    const recentMACD = macdValues.slice(-recentCandles).map((m) => m?.MACD || 0);
    const recentStoch = stochValues.slice(-recentCandles).map((s) => s?.k || 50);
    
    const priceHigher = recentPrices[recentPrices.length - 1] > recentPrices[0];
    const priceLower = recentPrices[recentPrices.length - 1] < recentPrices[0];
    
    const rsiHigher = recentRSI[recentRSI.length - 1] > recentRSI[0];
    const rsiLower = recentRSI[recentRSI.length - 1] < recentRSI[0];
    
    const macdHigher = recentMACD[recentMACD.length - 1] > recentMACD[0];
    const macdLower = recentMACD[recentMACD.length - 1] < recentMACD[0];
    
    const stochHigher = recentStoch[recentStoch.length - 1] > recentStoch[0];
    const stochLower = recentStoch[recentStoch.length - 1] < recentStoch[0];
    
    const rsiDivergence = (priceHigher && rsiLower) ? "Bearish" :
                          (priceLower && rsiHigher) ? "Bullish" : "None";
    
    const macdDivergence = (priceHigher && macdLower) ? "Bearish" :
                           (priceLower && macdHigher) ? "Bullish" : "None";
    
    const stochDivergence = (priceHigher && stochLower) ? "Bearish" :
                            (priceLower && stochHigher) ? "Bullish" : "None";
    
    const bullishDivergences = [rsiDivergence, macdDivergence, stochDivergence].filter(d => d === "Bullish").length;
    const bearishDivergences = [rsiDivergence, macdDivergence, stochDivergence].filter(d => d === "Bearish").length;
    
    const overallSignal = bullishDivergences >= 2 ? "Bullish Divergence" :
                          bearishDivergences >= 2 ? "Bearish Divergence" : "No Divergence";
    
    return {
      rsiDivergence,
      macdDivergence,
      stochDivergence,
      overallSignal,
    };
  }

  calculateKAMA(candles: CandleData[], period: number = 10, fastPeriod: number = 2, slowPeriod: number = 30): {
    value: number;
    efficiency: number;
    trend: "Bullish" | "Bearish" | "Neutral";
  } {
    if (candles.length < period + 1) {
      const lastClose = candles[candles.length - 1]?.close || 0;
      return { value: lastClose, efficiency: 0, trend: "Neutral" };
    }

    const closes = candles.map((c) => c.close);
    const kamaValues: number[] = [];
    
    const fastSC = 2 / (fastPeriod + 1);
    const slowSC = 2 / (slowPeriod + 1);
    
    for (let i = period; i < closes.length; i++) {
      const change = Math.abs(closes[i] - closes[i - period]);
      
      let volatility = 0;
      for (let j = i - period + 1; j <= i; j++) {
        volatility += Math.abs(closes[j] - closes[j - 1]);
      }
      
      const efficiency = volatility !== 0 ? change / volatility : 0;
      
      const smoothingConstant = Math.pow(efficiency * (fastSC - slowSC) + slowSC, 2);
      
      const previousKAMA = kamaValues.length > 0 ? kamaValues[kamaValues.length - 1] : closes[i - 1];
      const kama = previousKAMA + smoothingConstant * (closes[i] - previousKAMA);
      
      kamaValues.push(kama);
    }
    
    const currentKAMA = kamaValues[kamaValues.length - 1] || closes[closes.length - 1];
    const previousKAMA = kamaValues[kamaValues.length - 2] || currentKAMA;
    const currentPrice = closes[closes.length - 1];
    
    const change = Math.abs(closes[closes.length - 1] - closes[closes.length - 1 - period]);
    let volatility = 0;
    for (let j = closes.length - period; j < closes.length; j++) {
      volatility += Math.abs(closes[j] - closes[j - 1]);
    }
    const efficiency = volatility !== 0 ? change / volatility : 0;
    
    const trend = currentKAMA > previousKAMA && currentPrice > currentKAMA ? "Bullish" :
                  currentKAMA < previousKAMA && currentPrice < currentKAMA ? "Bearish" : "Neutral";
    
    return {
      value: currentKAMA,
      efficiency: efficiency * 100,
      trend,
    };
  }

  calculateLinearRegressionForecast(candles: CandleData[], period: number = 20, forecastBars: number = 5): {
    slope: number;
    intercept: number;
    forecast: number;
    upper: number;
    lower: number;
    trend: "Uptrend" | "Downtrend" | "Sideways";
    strength: number;
  } {
    if (candles.length < Math.max(2, period)) {
      const lastClose = candles[candles.length - 1]?.close || 0;
      return {
        slope: 0,
        intercept: lastClose,
        forecast: lastClose,
        upper: lastClose,
        lower: lastClose,
        trend: "Sideways",
        strength: 0,
      };
    }

    const recentCandles = candles.slice(-period);
    const closes = recentCandles.map((c) => c.close);
    
    const n = closes.length;
    
    if (n < 2) {
      const lastClose = closes[0] || 0;
      return {
        slope: 0,
        intercept: lastClose,
        forecast: lastClose,
        upper: lastClose,
        lower: lastClose,
        trend: "Sideways",
        strength: 0,
      };
    }
    const x = Array.from({ length: n }, (_, i) => i);
    
    const sumX = x.reduce((a, b) => a + b, 0);
    const sumY = closes.reduce((a, b) => a + b, 0);
    const sumXY = x.reduce((sum, xi, i) => sum + xi * closes[i], 0);
    const sumX2 = x.reduce((sum, xi) => sum + xi * xi, 0);
    
    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;
    
    const regressionValues = x.map((xi) => slope * xi + intercept);
    
    const residuals = closes.map((y, i) => y - regressionValues[i]);
    const variance = residuals.reduce((sum, r) => sum + r * r, 0) / n;
    const stdDev = Math.sqrt(variance);
    
    const forecastX = n + forecastBars - 1;
    const forecast = slope * forecastX + intercept;
    const upper = forecast + 2 * stdDev;
    const lower = forecast - 2 * stdDev;
    
    const totalVariance = closes.reduce((sum, y) => {
      const mean = sumY / n;
      return sum + Math.pow(y - mean, 2);
    }, 0) / n;
    
    const rSquared = totalVariance !== 0 ? Math.max(0, Math.min(1, 1 - (variance / totalVariance))) : 0;
    
    const trend = slope > 0.001 ? "Uptrend" : slope < -0.001 ? "Downtrend" : "Sideways";
    
    return {
      slope,
      intercept,
      forecast,
      upper,
      lower,
      trend,
      strength: rSquared * 100,
    };
  }

  calculateSmartMoneyIndex(candles: CandleData[]): {
    value: number;
    signal: "Accumulation" | "Distribution" | "Neutral";
    trend: "Bullish" | "Bearish" | "Neutral";
  } {
    if (candles.length < 2) {
      return { value: 0, signal: "Neutral", trend: "Neutral" };
    }

    let smiValue = 0;
    const smiHistory: number[] = [];
    
    for (let i = 1; i < candles.length; i++) {
      const currentCandle = candles[i];
      const previousClose = candles[i - 1].close;
      
      const intraday = currentCandle.close - currentCandle.open;
      const overnight = currentCandle.open - previousClose;
      
      const volume = currentCandle.volume || 1;
      
      if (intraday > 0 && overnight < 0) {
        smiValue += volume;
      } else if (intraday < 0 && overnight > 0) {
        smiValue -= volume;
      }
      
      smiHistory.push(smiValue);
    }
    
    const currentSMI = smiValue;
    const recentSMI = smiHistory.slice(-10);
    
    if (recentSMI.length < 2) {
      return { value: currentSMI, signal: "Neutral", trend: "Neutral" };
    }
    
    const smiChange = currentSMI - recentSMI[0];
    const smiSlope = smiChange / recentSMI.length;
    
    const lastCandle = candles[candles.length - 1];
    const intradayMove = lastCandle.close - lastCandle.open;
    const volume = lastCandle.volume || 1;
    
    let signal: "Accumulation" | "Distribution" | "Neutral" = "Neutral";
    if (intradayMove > 0 && volume > 0) {
      signal = "Accumulation";
    } else if (intradayMove < 0 && volume > 0) {
      signal = "Distribution";
    }
    
    const trend = smiSlope > 0 ? "Bullish" : smiSlope < 0 ? "Bearish" : "Neutral";
    
    return {
      value: currentSMI,
      signal,
      trend,
    };
  }

  generateIndicators(candles: CandleData[], mode: "scalping" | "swing" = "swing"): TechnicalIndicator[] {
    const rsi = this.calculateRSI(candles);
    const macd = this.calculateMACD(candles);
    const ema9 = this.calculateEMA(candles, 9);
    const ema21 = this.calculateEMA(candles, 21);
    const ema50 = this.calculateEMA(candles, 50);
    const bb = this.calculateBollingerBands(candles);
    const stoch = this.calculateStochastic(candles);
    const adx = this.calculateADX(candles);
    const psar = this.calculatePSAR(candles);
    const vwap = this.calculateVWAP(candles);
    const ichimoku = this.calculateIchimoku(candles);
    const fib = this.calculateFibonacci(candles);
    
    const cci = this.calculateCCI(candles);
    const williamsR = this.calculateWilliamsR(candles);
    const atr = this.calculateATR(candles);
    const supertrend = this.calculateSupertrend(candles);
    const ema5 = this.calculateEMA(candles, 5);
    const ema13 = this.calculateEMA(candles, 13);
    
    const obv = this.calculateOBV(candles);
    const pivotPoints = this.calculatePivotPoints(candles);
    const heikinAshi = this.calculateHeikinAshi(candles);
    const candlePatterns = this.detectCandlestickPatterns(candles);
    const divergences = this.detectDivergences(candles);
    
    const kama = this.calculateKAMA(candles);
    const linRegForecast = this.calculateLinearRegressionForecast(candles);
    const smartMoneyIndex = this.calculateSmartMoneyIndex(candles);

    const currentPrice = candles[candles.length - 1].close;

    const indicators: TechnicalIndicator[] = [
      {
        name: "RSI (14)",
        value: rsi.toFixed(1),
        signal: rsi < 30 ? "Oversold" : rsi > 70 ? "Overbought" : "Neutral",
      },
      {
        name: "MACD",
        value: macd.histogram.toFixed(2),
        signal: macd.histogram > 0 ? "Bullish Cross" : "Bearish Cross",
      },
      {
        name: "EMA (9)",
        value: ema9.toFixed(2),
        signal: currentPrice > ema9 ? "Bullish" : "Bearish",
      },
      {
        name: "EMA (21)",
        value: ema21.toFixed(2),
        signal: currentPrice > ema21 ? "Bullish" : "Bearish",
      },
      {
        name: "EMA (50)",
        value: ema50.toFixed(2),
        signal: currentPrice > ema50 ? "Bullish" : "Bearish",
      },
      {
        name: "Bollinger Bands",
        value: `${bb.upper.toFixed(2)}`,
        signal: currentPrice > bb.upper ? "Overbought" : currentPrice < bb.lower ? "Oversold" : "Neutral",
      },
      {
        name: "Stochastic",
        value: stoch.k.toFixed(1),
        signal: stoch.k < 20 ? "Oversold" : stoch.k > 80 ? "Overbought" : "Neutral",
      },
      {
        name: "ADX (14)",
        value: adx.adx.toFixed(1),
        signal: adx.adx > 25 ? (adx.pdi > adx.mdi ? "Strong Uptrend" : "Strong Downtrend") : "Weak/No Trend",
      },
      {
        name: "Parabolic SAR",
        value: psar.toFixed(2),
        signal: currentPrice > psar ? "Bullish" : "Bearish",
      },
      {
        name: "VWAP",
        value: vwap.toFixed(2),
        signal: currentPrice > vwap ? "Above VWAP (Bullish)" : "Below VWAP (Bearish)",
      },
      {
        name: "Ichimoku Tenkan-sen",
        value: ichimoku.tenkanSen.toFixed(2),
        signal: currentPrice > ichimoku.tenkanSen ? "Bullish" : "Bearish",
      },
      {
        name: "Ichimoku Kijun-sen",
        value: ichimoku.kijunSen.toFixed(2),
        signal: currentPrice > ichimoku.kijunSen ? "Bullish" : "Bearish",
      },
      {
        name: "Ichimoku Cloud",
        value: `A:${ichimoku.senkouSpanA.toFixed(2)} B:${ichimoku.senkouSpanB.toFixed(2)}`,
        signal: ichimoku.cloudSignal === "Bullish" ? "Above Cloud (Bullish)" : 
                ichimoku.cloudSignal === "Bearish" ? "Below Cloud (Bearish)" : "Neutral",
      },
      {
        name: "Fib 61.8% Retrace",
        value: fib.levels.find(l => l.level === 0.618)?.price.toFixed(2) || "N/A",
        signal: currentPrice > (fib.levels.find(l => l.level === 0.618)?.price || 0) ? "Above Fib 0.618" : "Below Fib 0.618",
      },
      {
        name: "Fib 50% Level",
        value: fib.levels.find(l => l.level === 0.5)?.price.toFixed(2) || "N/A",
        signal: fib.trend === "Uptrend" ? "Bullish" : "Bearish",
      },
      {
        name: "OBV",
        value: obv.toFixed(0),
        signal: obv > 0 ? "Accumulation" : "Distribution",
      },
      {
        name: "Pivot Point",
        value: pivotPoints.pivot.toFixed(2),
        signal: currentPrice > pivotPoints.pivot ? "Above Pivot (Bullish)" : "Below Pivot (Bearish)",
      },
      {
        name: "Pivot R1/S1",
        value: `R1:${pivotPoints.r1.toFixed(2)} S1:${pivotPoints.s1.toFixed(2)}`,
        signal: currentPrice > pivotPoints.r1 ? "Above R1" : currentPrice < pivotPoints.s1 ? "Below S1" : "Between R1/S1",
      },
      {
        name: "Heikin Ashi Trend",
        value: `${heikinAshi.close.toFixed(2)}`,
        signal: heikinAshi.trend,
      },
      {
        name: "Candlestick Patterns",
        value: candlePatterns.patterns.length > 0 ? candlePatterns.patterns.join(", ") : "No Pattern",
        signal: candlePatterns.signal,
      },
      {
        name: "Divergence Analysis",
        value: `RSI:${divergences.rsiDivergence} MACD:${divergences.macdDivergence}`,
        signal: divergences.overallSignal,
      },
      {
        name: "KAMA (Adaptive)",
        value: `${kama.value.toFixed(2)} (Eff: ${kama.efficiency.toFixed(0)}%)`,
        signal: kama.trend,
      },
      {
        name: "Linear Regression Forecast",
        value: `${linRegForecast.forecast.toFixed(2)} (R²: ${linRegForecast.strength.toFixed(0)}%)`,
        signal: linRegForecast.trend === "Uptrend" ? "Bullish" : linRegForecast.trend === "Downtrend" ? "Bearish" : "Neutral",
      },
      {
        name: "Smart Money Index",
        value: `${smartMoneyIndex.value.toFixed(0)} (${smartMoneyIndex.trend})`,
        signal: smartMoneyIndex.signal,
      },
    ];

    if (mode === "scalping") {
      indicators.push(
        {
          name: "CCI (20)",
          value: cci.toFixed(1),
          signal: cci > 100 ? "Overbought" : cci < -100 ? "Oversold" : "Neutral",
        },
        {
          name: "Williams %R",
          value: williamsR.toFixed(1),
          signal: williamsR > -20 ? "Overbought" : williamsR < -80 ? "Oversold" : "Neutral",
        },
        {
          name: "ATR (14)",
          value: atr.toFixed(2),
          signal: atr > (currentPrice * 0.015) ? "High Volatility" : "Low Volatility",
        },
        {
          name: "Supertrend",
          value: supertrend.supertrend.toFixed(2),
          signal: supertrend.direction,
        },
        {
          name: "EMA (5)",
          value: ema5.toFixed(2),
          signal: currentPrice > ema5 ? "Bullish" : "Bearish",
        },
        {
          name: "EMA (13)",
          value: ema13.toFixed(2),
          signal: currentPrice > ema13 ? "Bullish" : "Bearish",
        }
      );
    }

    return indicators;
  }

  analyzeTimeframe(candles: CandleData[], timeframe: string): TimeframeAnalysis {
    const rsi = this.calculateRSI(candles);
    const macd = this.calculateMACD(candles);
    const ema9 = this.calculateEMA(candles, 9);
    const currentPrice = candles[candles.length - 1].close;

    let bullishSignals = 0;
    let bearishSignals = 0;

    if (rsi < 40) bullishSignals++;
    if (rsi > 60) bearishSignals++;
    if (macd.histogram > 0) bullishSignals++;
    if (macd.histogram < 0) bearishSignals++;
    if (currentPrice > ema9) bullishSignals++;
    if (currentPrice < ema9) bearishSignals++;

    const totalSignals = bullishSignals + bearishSignals;
    const strength = totalSignals > 0 ? Math.round((Math.max(bullishSignals, bearishSignals) / totalSignals) * 100) : 50;

    let signal: "BUY" | "SELL" | "NEUTRAL" = "NEUTRAL";
    if (bullishSignals > bearishSignals) signal = "BUY";
    if (bearishSignals > bullishSignals) signal = "SELL";

    return {
      timeframe,
      signal,
      strength,
      rsi,
      macd: macd.histogram > 0 ? "Bullish" : "Bearish",
    };
  }
}

export const indicatorsService = new TechnicalIndicatorsService();
