import { WebSocketServer, WebSocket } from "ws";
import type { Server } from "http";
import type { PriceData, Signal, TradingMode } from "@shared/schema";
import { marketDataService } from "./marketData";
import { indicatorsService } from "./indicators";
import { aiSignalGenerator } from "./aiSignalGenerator";

interface ClientData {
  ws: WebSocket;
  tradingMode: TradingMode;
}

export class TradingWebSocketServer {
  private wss: WebSocketServer;
  private clients: Map<WebSocket, ClientData> = new Map();
  private priceUpdateInterval: NodeJS.Timeout | null = null;
  private signalGenerationInterval: NodeJS.Timeout | null = null;

  constructor(server: Server) {
    this.wss = new WebSocketServer({ server, path: "/ws" });
    this.setupWebSocket();
  }

  private setupWebSocket() {
    this.wss.on("connection", (ws: WebSocket) => {
      console.log("New WebSocket client connected");
      this.clients.set(ws, { ws, tradingMode: "swing" });

      ws.on("message", (message: string) => {
        try {
          const data = JSON.parse(message.toString());
          if (data.type === "set_trading_mode") {
            const clientData = this.clients.get(ws);
            if (clientData) {
              clientData.tradingMode = data.mode;
              console.log(`Client trading mode set to: ${data.mode}`);
            }
          }
        } catch (error) {
          console.error("Error parsing WebSocket message:", error);
        }
      });

      ws.on("close", () => {
        console.log("WebSocket client disconnected");
        this.clients.delete(ws);
      });

      ws.on("error", (error) => {
        console.error("WebSocket error:", error);
        this.clients.delete(ws);
      });

      this.sendInitialData(ws);
    });
  }

  private async sendInitialData(ws: WebSocket) {
    try {
      const { storage } = await import("../storage");
      const [xauPrice, btcPrice, recentSignals] = await Promise.all([
        marketDataService.getXAUUSDPrice(),
        marketDataService.getBTCUSDPrice(),
        storage.getSignals(10),
      ]);

      ws.send(
        JSON.stringify({
          type: "price_update",
          data: { xauusd: xauPrice, btcusd: btcPrice },
        })
      );

      if (recentSignals.length > 0) {
        ws.send(
          JSON.stringify({
            type: "initial_signals",
            data: recentSignals,
          })
        );
      }
    } catch (error) {
      console.error("Error sending initial data:", error);
    }
  }

  startPriceUpdates() {
    if (this.priceUpdateInterval) return;

    this.priceUpdateInterval = setInterval(async () => {
      try {
        const [xauPrice, btcPrice] = await Promise.all([
          marketDataService.getXAUUSDPrice(),
          marketDataService.getBTCUSDPrice(),
        ]);

        this.broadcast({
          type: "price_update",
          data: { xauusd: xauPrice, btcusd: btcPrice },
        });
      } catch (error) {
        console.error("Error updating prices:", error);
      }
    }, 3000);

    console.log("Price updates started");
  }

  startSignalGeneration() {
    if (this.signalGenerationInterval) return;

    this.signalGenerationInterval = setInterval(async () => {
      try {
        const uniqueModes = new Set<TradingMode>();
        this.clients.forEach(client => uniqueModes.add(client.tradingMode));

        for (const mode of uniqueModes) {
          const markets: ("XAU/USD" | "BTC/USD")[] = ["XAU/USD", "BTC/USD"];
          const randomMarket = markets[Math.floor(Math.random() * markets.length)];

          const [candles, priceData] =
            randomMarket === "XAU/USD"
              ? await Promise.all([
                  marketDataService.getXAUUSDCandles("5m", 100),
                  marketDataService.getXAUUSDPrice(),
                ])
              : await Promise.all([
                  marketDataService.getBTCUSDCandles("5m", 100),
                  marketDataService.getBTCUSDPrice(),
                ]);

          const indicators = indicatorsService.generateIndicators(candles, mode);
          const signal = await aiSignalGenerator.generateSignal(
            randomMarket,
            priceData.price,
            indicators,
            candles,
            mode
          );

          if (signal) {
            console.log(`Generated ${signal.direction} signal for ${randomMarket} (${mode} mode)`);
            
            const { storage } = await import("../storage");
            await storage.addSignal(signal);
            
            this.broadcastToMode(
              {
                type: "new_signal",
                data: signal,
              },
              mode
            );

            this.broadcastToMode(
              {
                type: "indicators_update",
                data: { market: randomMarket, indicators },
              },
              mode
            );
          }
        }
      } catch (error) {
        console.error("Error generating signal:", error);
      }
    }, 60000);

    console.log("Signal generation started");
  }

  private broadcastToMode(message: any, mode: TradingMode) {
    const data = JSON.stringify(message);
    this.clients.forEach((clientData, ws) => {
      if (clientData.tradingMode === mode && ws.readyState === WebSocket.OPEN) {
        ws.send(data);
      }
    });
  }

  private broadcast(message: any) {
    const data = JSON.stringify(message);
    this.clients.forEach((clientData, ws) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(data);
      }
    });
  }

  stop() {
    if (this.priceUpdateInterval) {
      clearInterval(this.priceUpdateInterval);
      this.priceUpdateInterval = null;
    }
    if (this.signalGenerationInterval) {
      clearInterval(this.signalGenerationInterval);
      this.signalGenerationInterval = null;
    }
    this.wss.close();
  }
}
