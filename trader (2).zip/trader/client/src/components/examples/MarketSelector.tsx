import { MarketSelector } from "../MarketSelector";

export default function MarketSelectorExample() {
  return (
    <div className="p-6">
      <MarketSelector />
    </div>
  );
}
