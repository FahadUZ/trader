import { RSI, MACD, EMA, BollingerBands, Stochastic, ADX, PSAR } from "technicalindicators";
import type { CandleData, TechnicalIndicator, TimeframeAnalysis } from "@shared/schema";

export class TechnicalIndicatorsService {
  calculateRSI(candles: CandleData[], period: number = 14): number {
    const closes = candles.map((c) => c.close);
    const rsiValues = RSI.calculate({ values: closes, period });
    return rsiValues[rsiValues.length - 1] || 50;
  }

  calculateMACD(candles: CandleData[]): {
    value: number;
    signal: number;
    histogram: number;
  } {
    const closes = candles.map((c) => c.close);
    const macdValues = MACD.calculate({
      values: closes,
      fastPeriod: 12,
      slowPeriod: 26,
      signalPeriod: 9,
      SimpleMAOscillator: false,
      SimpleMASignal: false,
    });

    const latest = macdValues[macdValues.length - 1];
    if (!latest) {
      return { value: 0, signal: 0, histogram: 0 };
    }

    return {
      value: latest.MACD || 0,
      signal: latest.signal || 0,
      histogram: latest.histogram || 0,
    };
  }

  calculateEMA(candles: CandleData[], period: number): number {
    const closes = candles.map((c) => c.close);
    const emaValues = EMA.calculate({ values: closes, period });
    return emaValues[emaValues.length - 1] || closes[closes.length - 1];
  }

  calculateBollingerBands(candles: CandleData[], period: number = 20): {
    upper: number;
    middle: number;
    lower: number;
  } {
    const closes = candles.map((c) => c.close);
    const bbValues = BollingerBands.calculate({
      values: closes,
      period,
      stdDev: 2,
    });

    const latest = bbValues[bbValues.length - 1];
    if (!latest) {
      const lastClose = closes[closes.length - 1];
      return { upper: lastClose, middle: lastClose, lower: lastClose };
    }

    return {
      upper: latest.upper,
      middle: latest.middle,
      lower: latest.lower,
    };
  }

  calculateStochastic(candles: CandleData[]): { k: number; d: number } {
    const highs = candles.map((c) => c.high);
    const lows = candles.map((c) => c.low);
    const closes = candles.map((c) => c.close);

    const stochValues = Stochastic.calculate({
      high: highs,
      low: lows,
      close: closes,
      period: 14,
      signalPeriod: 3,
    });

    const latest = stochValues[stochValues.length - 1];
    if (!latest) {
      return { k: 50, d: 50 };
    }

    return { k: latest.k, d: latest.d };
  }

  calculateADX(candles: CandleData[], period: number = 14): { adx: number; pdi: number; mdi: number } {
    const highs = candles.map((c) => c.high);
    const lows = candles.map((c) => c.low);
    const closes = candles.map((c) => c.close);

    const adxValues = ADX.calculate({
      high: highs,
      low: lows,
      close: closes,
      period,
    });

    const latest = adxValues[adxValues.length - 1];
    if (!latest) {
      return { adx: 0, pdi: 0, mdi: 0 };
    }

    return { 
      adx: latest.adx || 0, 
      pdi: latest.pdi || 0, 
      mdi: latest.mdi || 0 
    };
  }

  calculatePSAR(candles: CandleData[]): number {
    const highs = candles.map((c) => c.high);
    const lows = candles.map((c) => c.low);

    const psarValues = PSAR.calculate({
      high: highs,
      low: lows,
      step: 0.02,
      max: 0.2,
    });

    return psarValues[psarValues.length - 1] || candles[candles.length - 1].close;
  }

  calculateVWAP(candles: CandleData[]): number {
    let cumulativePriceVolume = 0;
    let cumulativeVolume = 0;

    for (const candle of candles) {
      const typicalPrice = (candle.high + candle.low + candle.close) / 3;
      const volume = candle.volume || 1;
      cumulativePriceVolume += typicalPrice * volume;
      cumulativeVolume += volume;
    }

    return cumulativeVolume > 0 ? cumulativePriceVolume / cumulativeVolume : candles[candles.length - 1].close;
  }

  calculateIchimoku(candles: CandleData[]): {
    tenkanSen: number;
    kijunSen: number;
    senkouSpanA: number;
    senkouSpanB: number;
    chikouSpan: number;
    cloudSignal: "Bullish" | "Bearish" | "Neutral";
  } {
    if (candles.length < 52) {
      const lastClose = candles[candles.length - 1]?.close || 0;
      return {
        tenkanSen: lastClose,
        kijunSen: lastClose,
        senkouSpanA: lastClose,
        senkouSpanB: lastClose,
        chikouSpan: lastClose,
        cloudSignal: "Neutral",
      };
    }

    const getHighLow = (data: CandleData[], period: number, offset: number = 0) => {
      const endIdx = data.length - offset;
      const startIdx = Math.max(0, endIdx - period);
      const slice = data.slice(startIdx, endIdx);
      if (slice.length === 0) return 0;
      const high = Math.max(...slice.map((c) => c.high));
      const low = Math.min(...slice.map((c) => c.low));
      return (high + low) / 2;
    };

    const tenkanSen = getHighLow(candles, 9, 0);
    const kijunSen = getHighLow(candles, 26, 0);
    const senkouSpanA = (tenkanSen + kijunSen) / 2;
    const senkouSpanB = getHighLow(candles, 52, 0);
    
    const chikouIdx = Math.max(0, candles.length - 26);
    const chikouSpan = candles[chikouIdx]?.close || candles[candles.length - 1].close;

    const currentPrice = candles[candles.length - 1].close;
    const cloudTop = Math.max(senkouSpanA, senkouSpanB);
    const cloudBottom = Math.min(senkouSpanA, senkouSpanB);

    let cloudSignal: "Bullish" | "Bearish" | "Neutral" = "Neutral";
    if (currentPrice > cloudTop && senkouSpanA > senkouSpanB) {
      cloudSignal = "Bullish";
    } else if (currentPrice < cloudBottom && senkouSpanA < senkouSpanB) {
      cloudSignal = "Bearish";
    }

    return {
      tenkanSen,
      kijunSen,
      senkouSpanA,
      senkouSpanB,
      chikouSpan,
      cloudSignal,
    };
  }

  calculateFibonacci(candles: CandleData[]): {
    high: number;
    low: number;
    swingHigh: number;
    swingLow: number;
    levels: { level: number; price: number; label: string }[];
    trend: "Uptrend" | "Downtrend";
  } {
    if (candles.length < 20) {
      const lastClose = candles[candles.length - 1]?.close || 0;
      return {
        high: lastClose,
        low: lastClose,
        swingHigh: lastClose,
        swingLow: lastClose,
        levels: [],
        trend: "Uptrend",
      };
    }

    const findSwingHigh = (data: CandleData[], lookback: number = 20): number => {
      const recentCandles = data.slice(-lookback);
      const highs = recentCandles.map(c => c.high);
      let maxHigh = -Infinity;
      let maxIdx = -1;
      
      for (let i = 2; i < highs.length - 2; i++) {
        if (highs[i] > highs[i-1] && highs[i] > highs[i-2] &&
            highs[i] > highs[i+1] && highs[i] > highs[i+2] &&
            highs[i] > maxHigh) {
          maxHigh = highs[i];
          maxIdx = i;
        }
      }
      
      return maxIdx >= 0 ? maxHigh : Math.max(...highs);
    };

    const findSwingLow = (data: CandleData[], lookback: number = 20): number => {
      const recentCandles = data.slice(-lookback);
      const lows = recentCandles.map(c => c.low);
      let minLow = Infinity;
      let minIdx = -1;
      
      for (let i = 2; i < lows.length - 2; i++) {
        if (lows[i] < lows[i-1] && lows[i] < lows[i-2] &&
            lows[i] < lows[i+1] && lows[i] < lows[i+2] &&
            lows[i] < minLow) {
          minLow = lows[i];
          minIdx = i;
        }
      }
      
      return minIdx >= 0 ? minLow : Math.min(...lows);
    };

    const swingHigh = findSwingHigh(candles, 30);
    const swingLow = findSwingLow(candles, 30);
    const diff = swingHigh - swingLow;
    const currentPrice = candles[candles.length - 1].close;
    
    const trend: "Uptrend" | "Downtrend" = currentPrice > (swingHigh + swingLow) / 2 ? "Uptrend" : "Downtrend";

    const fibLevels = [
      { level: 0, label: "0%" },
      { level: 0.236, label: "23.6%" },
      { level: 0.382, label: "38.2%" },
      { level: 0.5, label: "50%" },
      { level: 0.618, label: "61.8%" },
      { level: 0.786, label: "78.6%" },
      { level: 1, label: "100%" }
    ];

    const levels = fibLevels.map((fib) => ({
      level: fib.level,
      price: swingHigh - diff * fib.level,
      label: fib.label,
    }));

    return {
      high: swingHigh,
      low: swingLow,
      swingHigh,
      swingLow,
      levels,
      trend,
    };
  }

  generateIndicators(candles: CandleData[]): TechnicalIndicator[] {
    const rsi = this.calculateRSI(candles);
    const macd = this.calculateMACD(candles);
    const ema9 = this.calculateEMA(candles, 9);
    const ema21 = this.calculateEMA(candles, 21);
    const ema50 = this.calculateEMA(candles, 50);
    const bb = this.calculateBollingerBands(candles);
    const stoch = this.calculateStochastic(candles);
    const adx = this.calculateADX(candles);
    const psar = this.calculatePSAR(candles);
    const vwap = this.calculateVWAP(candles);
    const ichimoku = this.calculateIchimoku(candles);
    const fib = this.calculateFibonacci(candles);

    const currentPrice = candles[candles.length - 1].close;

    const indicators: TechnicalIndicator[] = [
      {
        name: "RSI (14)",
        value: rsi.toFixed(1),
        signal: rsi < 30 ? "Oversold" : rsi > 70 ? "Overbought" : "Neutral",
      },
      {
        name: "MACD",
        value: macd.histogram.toFixed(2),
        signal: macd.histogram > 0 ? "Bullish Cross" : "Bearish Cross",
      },
      {
        name: "EMA (9)",
        value: ema9.toFixed(2),
        signal: currentPrice > ema9 ? "Bullish" : "Bearish",
      },
      {
        name: "EMA (21)",
        value: ema21.toFixed(2),
        signal: currentPrice > ema21 ? "Bullish" : "Bearish",
      },
      {
        name: "EMA (50)",
        value: ema50.toFixed(2),
        signal: currentPrice > ema50 ? "Bullish" : "Bearish",
      },
      {
        name: "Bollinger Bands",
        value: `${bb.upper.toFixed(2)}`,
        signal: currentPrice > bb.upper ? "Overbought" : currentPrice < bb.lower ? "Oversold" : "Neutral",
      },
      {
        name: "Stochastic",
        value: stoch.k.toFixed(1),
        signal: stoch.k < 20 ? "Oversold" : stoch.k > 80 ? "Overbought" : "Neutral",
      },
      {
        name: "ADX (14)",
        value: adx.adx.toFixed(1),
        signal: adx.adx > 25 ? (adx.pdi > adx.mdi ? "Strong Uptrend" : "Strong Downtrend") : "Weak/No Trend",
      },
      {
        name: "Parabolic SAR",
        value: psar.toFixed(2),
        signal: currentPrice > psar ? "Bullish" : "Bearish",
      },
      {
        name: "VWAP",
        value: vwap.toFixed(2),
        signal: currentPrice > vwap ? "Above VWAP (Bullish)" : "Below VWAP (Bearish)",
      },
      {
        name: "Ichimoku Tenkan-sen",
        value: ichimoku.tenkanSen.toFixed(2),
        signal: currentPrice > ichimoku.tenkanSen ? "Bullish" : "Bearish",
      },
      {
        name: "Ichimoku Kijun-sen",
        value: ichimoku.kijunSen.toFixed(2),
        signal: currentPrice > ichimoku.kijunSen ? "Bullish" : "Bearish",
      },
      {
        name: "Ichimoku Cloud",
        value: `A:${ichimoku.senkouSpanA.toFixed(2)} B:${ichimoku.senkouSpanB.toFixed(2)}`,
        signal: ichimoku.cloudSignal === "Bullish" ? "Above Cloud (Bullish)" : 
                ichimoku.cloudSignal === "Bearish" ? "Below Cloud (Bearish)" : "Neutral",
      },
      {
        name: "Fib 61.8% Retrace",
        value: fib.levels.find(l => l.level === 0.618)?.price.toFixed(2) || "N/A",
        signal: currentPrice > (fib.levels.find(l => l.level === 0.618)?.price || 0) ? "Above Fib 0.618" : "Below Fib 0.618",
      },
      {
        name: "Fib 50% Level",
        value: fib.levels.find(l => l.level === 0.5)?.price.toFixed(2) || "N/A",
        signal: fib.trend === "Uptrend" ? "Bullish" : "Bearish",
      },
    ];

    return indicators;
  }

  analyzeTimeframe(candles: CandleData[], timeframe: string): TimeframeAnalysis {
    const rsi = this.calculateRSI(candles);
    const macd = this.calculateMACD(candles);
    const ema9 = this.calculateEMA(candles, 9);
    const currentPrice = candles[candles.length - 1].close;

    let bullishSignals = 0;
    let bearishSignals = 0;

    if (rsi < 40) bullishSignals++;
    if (rsi > 60) bearishSignals++;
    if (macd.histogram > 0) bullishSignals++;
    if (macd.histogram < 0) bearishSignals++;
    if (currentPrice > ema9) bullishSignals++;
    if (currentPrice < ema9) bearishSignals++;

    const totalSignals = bullishSignals + bearishSignals;
    const strength = totalSignals > 0 ? Math.round((Math.max(bullishSignals, bearishSignals) / totalSignals) * 100) : 50;

    let signal: "BUY" | "SELL" | "NEUTRAL" = "NEUTRAL";
    if (bullishSignals > bearishSignals) signal = "BUY";
    if (bearishSignals > bullishSignals) signal = "SELL";

    return {
      timeframe,
      signal,
      strength,
      rsi,
      macd: macd.histogram > 0 ? "Bullish" : "Bearish",
    };
  }
}

export const indicatorsService = new TechnicalIndicatorsService();
